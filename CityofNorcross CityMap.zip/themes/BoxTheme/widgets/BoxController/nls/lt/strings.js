define({
  "_widgetLabel": "Dėžučių valdiklis"
});