define({
  "_widgetLabel": "Controler cutie"
});