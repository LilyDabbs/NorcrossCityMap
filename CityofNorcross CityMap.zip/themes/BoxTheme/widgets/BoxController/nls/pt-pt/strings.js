define({
  "_widgetLabel": "Controlador de Caixa"
});