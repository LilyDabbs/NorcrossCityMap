define({
  "_widgetLabel": "方塊控制器"
});