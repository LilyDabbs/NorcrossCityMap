define({
  "_themeLabel": "Teema Box",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_top": "Ülemine paigutus"
});