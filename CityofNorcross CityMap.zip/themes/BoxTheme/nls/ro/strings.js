define({
  "_themeLabel": "Temă cutie",
  "_layout_default": "Aspect implicit",
  "_layout_top": "Aspect sus"
});