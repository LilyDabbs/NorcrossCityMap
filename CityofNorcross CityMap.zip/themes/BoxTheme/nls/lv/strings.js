define({
  "_themeLabel": "Lodziņa tēma",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_top": "Augšdaļas izkārtojums"
});