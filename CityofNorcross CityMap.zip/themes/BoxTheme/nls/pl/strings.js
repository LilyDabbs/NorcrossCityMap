define({
  "_themeLabel": "Motyw Pole",
  "_layout_default": "Kompozycja domyślna",
  "_layout_top": "Kompozycja górna"
});